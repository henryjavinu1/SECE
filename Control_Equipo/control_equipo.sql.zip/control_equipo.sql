-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 09-12-2018 a las 01:57:01
-- Versión del servidor: 5.7.21
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `control_equipo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `centro`
--

DROP TABLE IF EXISTS `centro`;
CREATE TABLE IF NOT EXISTS `centro` (
  `ID_CENTRO` int(7) NOT NULL AUTO_INCREMENT,
  `CENTRO` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_CENTRO`)
) ENGINE=InnoDB AUTO_INCREMENT=31101002 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `centro`
--

INSERT INTO `centro` (`ID_CENTRO`, `CENTRO`) VALUES
(31101000, 'sistemas'),
(31101001, 'bodega');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compania`
--

DROP TABLE IF EXISTS `compania`;
CREATE TABLE IF NOT EXISTS `compania` (
  `ID_COMP` int(11) NOT NULL AUTO_INCREMENT,
  `COMPANIA` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`ID_COMP`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `compania`
--

INSERT INTO `compania` (`ID_COMP`, `COMPANIA`) VALUES
(1, 'wal'),
(2, 'mirror'),
(3, 'mirror');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE IF NOT EXISTS `departamento` (
  `ID_DEPTO` int(11) NOT NULL AUTO_INCREMENT,
  `DEPARTAMENTO` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_DEPTO`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`ID_DEPTO`, `DEPARTAMENTO`) VALUES
(1, 'it'),
(2, 'mantenimiento'),
(3, ''),
(4, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipo`
--

DROP TABLE IF EXISTS `equipo`;
CREATE TABLE IF NOT EXISTS `equipo` (
  `CORRELATIVO` int(100) NOT NULL AUTO_INCREMENT,
  `SERIE` varchar(100) NOT NULL,
  `NOMBRE_EQUIPO` varchar(50) NOT NULL,
  `ID_ESTADO` int(11) DEFAULT NULL,
  `ID_RESP` int(11) DEFAULT NULL,
  `FECHA_INGRESO` date NOT NULL,
  `ID_COMP` int(11) DEFAULT NULL,
  `ID_DEPTO` int(11) DEFAULT NULL,
  `ID_TIPO` int(11) DEFAULT NULL,
  `ID_UBICACION` int(11) DEFAULT NULL,
  `ID_CENTRO` int(7) DEFAULT NULL,
  `ID_MARCA` int(11) NOT NULL,
  `ID_MOD` int(11) DEFAULT NULL,
  `IP_DIR` varchar(12) DEFAULT NULL,
  `MAC_WIFI` varchar(17) NOT NULL,
  `MAC_ETH` varchar(17) NOT NULL,
  `ID_PROV` int(11) DEFAULT NULL,
  `S.O` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`SERIE`),
  UNIQUE KEY `A_I` (`CORRELATIVO`),
  KEY `ID_MOD` (`ID_MOD`),
  KEY `ID_MARCA` (`ID_MARCA`),
  KEY `ID_CENTRO` (`ID_CENTRO`),
  KEY `ID_UBICACION` (`ID_UBICACION`),
  KEY `ID_DEPTO` (`ID_DEPTO`),
  KEY `ID_RES` (`ID_RESP`),
  KEY `ID_COMP` (`ID_COMP`),
  KEY `ID_TIPO` (`ID_TIPO`),
  KEY `ID_ESTADO` (`ID_ESTADO`),
  KEY `ID_PROV` (`ID_PROV`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `equipo`
--

INSERT INTO `equipo` (`CORRELATIVO`, `SERIE`, `NOMBRE_EQUIPO`, `ID_ESTADO`, `ID_RESP`, `FECHA_INGRESO`, `ID_COMP`, `ID_DEPTO`, `ID_TIPO`, `ID_UBICACION`, `ID_CENTRO`, `ID_MARCA`, `ID_MOD`, `IP_DIR`, `MAC_WIFI`, `MAC_ETH`, `ID_PROV`, `S.O`) VALUES
(4, '00002', 'PC2', 1, 1, '2018-11-21', 1, 1, 1, 1, 31101000, 1, 1, '1516516', '3.5544', '4454', 1, '1213565'),
(5, '0003', 'man15', 2, 2, '2018-11-15', 2, 2, 2, 2, 31101001, 3, 1, '000011313', '04045045', '40540540', 2, 'Windows px sp3'),
(6, '0005', 'pc_maria', 3, 2, '2018-11-24', 2, 2, 2, 3, 31101001, 1, 2, '00000003', '45546', '477667', 2, 'window 7'),
(7, '0006', 'prt', 1, 3, '2018-11-10', 3, 2, 3, 1, 31101000, 1, 2, '0003100', '00034', 'dv5a45', 2, 'windows 10'),
(3, 'dsacnj100', 'esl-mac', 1, 1, '2018-11-01', 1, 1, 1, 1, 31101000, 1, 1, '32345153213', '12133', '123241', 1, 'asdadvadv');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

DROP TABLE IF EXISTS `estado`;
CREATE TABLE IF NOT EXISTS `estado` (
  `ID_ESTADO` int(11) NOT NULL AUTO_INCREMENT,
  `ESTADO` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`ID_ESTADO`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`ID_ESTADO`, `ESTADO`) VALUES
(1, 'Bueno'),
(2, 'Malo'),
(3, 'Reparacion'),
(4, 'Descartado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

DROP TABLE IF EXISTS `marca`;
CREATE TABLE IF NOT EXISTS `marca` (
  `ID_MARCA` int(11) NOT NULL AUTO_INCREMENT,
  `MARCA` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_MARCA`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`ID_MARCA`, `MARCA`) VALUES
(1, 'Dell'),
(2, 'HP'),
(3, 'Lenovo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelo`
--

DROP TABLE IF EXISTS `modelo`;
CREATE TABLE IF NOT EXISTS `modelo` (
  `ID_MOD` int(11) NOT NULL AUTO_INCREMENT,
  `MODELO` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `ID_MARCA` int(11) NOT NULL,
  PRIMARY KEY (`ID_MOD`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `modelo`
--

INSERT INTO `modelo` (`ID_MOD`, `MODELO`, `ID_MARCA`) VALUES
(1, 'Latitude 5460', 1),
(2, 'Latitude 5480', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE IF NOT EXISTS `proveedores` (
  `ID_PROV` int(11) NOT NULL AUTO_INCREMENT,
  `NAME_PROV` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `DIRECCION` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `TELEFONO` int(25) DEFAULT NULL,
  `CELULAR` int(25) DEFAULT NULL,
  PRIMARY KEY (`ID_PROV`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`ID_PROV`, `NAME_PROV`, `DIRECCION`, `TELEFONO`, `CELULAR`) VALUES
(1, 'cod prod', 'san lorenzo', 33597500, 33597500),
(2, 'Hardware $ Software', 'Barrio El Centro, frente a paque central San Lore', 27815287, 33487525);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable`
--

DROP TABLE IF EXISTS `responsable`;
CREATE TABLE IF NOT EXISTS `responsable` (
  `ID_RESP` int(11) NOT NULL AUTO_INCREMENT,
  `NUM_ID` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `NOMBRES` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `APELLIDOS` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_RESP`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `responsable`
--

INSERT INTO `responsable` (`ID_RESP`, `NUM_ID`, `NOMBRES`, `APELLIDOS`) VALUES
(1, '1709-1993-00375', 'Henry Javier', 'Nuñez'),
(2, '', 'Maria Milagro', 'Flores'),
(3, '', 'Elmer Martin', 'Mayorca'),
(4, '1709-1990-00111', 'Luis Antonio', 'Funez '),
(5, '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo`
--

DROP TABLE IF EXISTS `tipo`;
CREATE TABLE IF NOT EXISTS `tipo` (
  `ID_TIPO` int(11) NOT NULL AUTO_INCREMENT,
  `TIPO` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_TIPO`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo`
--

INSERT INTO `tipo` (`ID_TIPO`, `TIPO`) VALUES
(1, 'Pc_Escritorio'),
(2, 'Pc Portatil'),
(3, 'Impresora');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

DROP TABLE IF EXISTS `ubicacion`;
CREATE TABLE IF NOT EXISTS `ubicacion` (
  `ID_UBICACION` int(11) NOT NULL AUTO_INCREMENT,
  `UBICACION` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_UBICACION`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`ID_UBICACION`, `UBICACION`) VALUES
(1, 'oficina de it'),
(2, 'Almacen y suministros'),
(3, 'Sala de conferencia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `ID_USER` int(11) NOT NULL AUTO_INCREMENT,
  `FIRTS_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `LAS_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `CONTRA` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish2_ci DEFAULT NULL,
  `USER` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `ID_RANGE` int(11) NOT NULL,
  PRIMARY KEY (`ID_USER`),
  UNIQUE KEY `USER` (`USER`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_USER`, `FIRTS_NAME`, `LAS_NAME`, `CONTRA`, `USER`, `EMAIL`, `ID_RANGE`) VALUES
(1, 'Henrry Javier', 'Nunez Turcios', 'abc', 'hnunez', 'hnunez@gmail.com', 1);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `equipo`
--
ALTER TABLE `equipo`
  ADD CONSTRAINT `equipo_ibfk_1` FOREIGN KEY (`ID_COMP`) REFERENCES `compania` (`ID_COMP`),
  ADD CONSTRAINT `equipo_ibfk_10` FOREIGN KEY (`ID_MARCA`) REFERENCES `marca` (`ID_MARCA`),
  ADD CONSTRAINT `equipo_ibfk_2` FOREIGN KEY (`ID_TIPO`) REFERENCES `tipo` (`ID_TIPO`),
  ADD CONSTRAINT `equipo_ibfk_3` FOREIGN KEY (`ID_RESP`) REFERENCES `responsable` (`ID_RESP`),
  ADD CONSTRAINT `equipo_ibfk_4` FOREIGN KEY (`ID_DEPTO`) REFERENCES `departamento` (`ID_DEPTO`),
  ADD CONSTRAINT `equipo_ibfk_5` FOREIGN KEY (`ID_ESTADO`) REFERENCES `estado` (`ID_ESTADO`),
  ADD CONSTRAINT `equipo_ibfk_6` FOREIGN KEY (`ID_PROV`) REFERENCES `proveedores` (`ID_PROV`),
  ADD CONSTRAINT `equipo_ibfk_7` FOREIGN KEY (`ID_UBICACION`) REFERENCES `ubicacion` (`ID_UBICACION`),
  ADD CONSTRAINT `equipo_ibfk_8` FOREIGN KEY (`ID_MOD`) REFERENCES `modelo` (`ID_MOD`),
  ADD CONSTRAINT `equipo_ibfk_9` FOREIGN KEY (`ID_CENTRO`) REFERENCES `centro` (`ID_CENTRO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
